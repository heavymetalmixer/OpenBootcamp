class Coche:
    def __init__(self, puertas: int):
        self.puertas = puertas
    
    def aumentarPuertas(self, aumento: int):
        misPuertas = self.puertas + aumento
        return(misPuertas)