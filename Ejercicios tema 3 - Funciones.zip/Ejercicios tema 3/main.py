import coche

def sumaTres(a: int, b: int, c: int):
    return(a+b+c)

suma = sumaTres(4, 5, 1)

# print("Los tres números sumados dan como resultado", str(suma))

carro = coche.Coche(2)
print("Ahora el número de puertas es",str(carro.aumentarPuertas(2)))