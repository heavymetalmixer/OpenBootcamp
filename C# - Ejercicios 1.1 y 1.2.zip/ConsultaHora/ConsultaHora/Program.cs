﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Introduce la hora actual de tu país aquí: ");
string hora = Console.ReadLine();
Console.WriteLine("La hora en tu PC es " + hora);
