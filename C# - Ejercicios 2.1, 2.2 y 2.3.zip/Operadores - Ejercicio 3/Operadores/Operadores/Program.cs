﻿int a = 10;
Console.WriteLine("Es a mayor o igual que 18? " + (a >= 18));

char jor = 'a';
Console.WriteLine("Es la jor por dentro 'a'? " + (jor == 'a'));

bool cond1 = true;
bool cond2 = false;
Console.WriteLine("Son cond1 y cond2 verdaderos? " + (cond1 && cond2));

Console.WriteLine("Son cond1 o cond2 verdaderos? " + (cond1 || cond2));