﻿string nombre = "";
string apellido = "";
int edad = 0;
int numero_id = 0;
bool sabe_programar = false;

Console.WriteLine("Cuál es su nombre? ");
nombre = Console.ReadLine();

Console.WriteLine("Cuál es su apellido? ");
apellido = Console.ReadLine();

Console.WriteLine("Cuál es su edad? ");
edad = Convert.ToInt16(Console.ReadLine());

Console.WriteLine("Cuál es su número de identificación? ");
numero_id = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Usted sabe programar? Ponga true de ser cierto o false de lo contrario ");
sabe_programar = Convert.ToBoolean(Console.ReadLine());

string mensaje = "Su nombre y apellido son " + nombre + " " + apellido + ". Tiene " + edad + " años. Su número de identifación es " +
numero_id + ". Usted sabe programar " + sabe_programar;

Console.WriteLine(mensaje);