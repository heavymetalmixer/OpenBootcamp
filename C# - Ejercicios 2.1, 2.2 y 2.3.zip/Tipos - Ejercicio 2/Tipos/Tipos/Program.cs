﻿// Coche
int puertas;
int ruedas;
string marca;
string itv;

// Mesa
float peso;
float largo;
string material;
string color;