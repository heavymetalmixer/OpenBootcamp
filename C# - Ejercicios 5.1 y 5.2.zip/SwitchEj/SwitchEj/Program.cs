﻿Console.WriteLine("Tenemos una lista de le nguajes de programación disponibles para que usted use en su proyecto de Back End, cuál prefiere?");
Console.WriteLine("a) C++");
Console.WriteLine("b) C#");
Console.WriteLine("c) Java");
Console.WriteLine("d) PHP");
Console.WriteLine("e) Javascript");
Console.WriteLine("f) Python");
Console.WriteLine("g) Go");
Console.Write("Introduzca la letra que represente su elección: ");
string lenguaje = Console.ReadLine();

switch (lenguaje) {
    case "a":
        Console.WriteLine("Usted escogió C++. Buena suerte con su proyecto!");
        break;
    case "b":
        Console.WriteLine("Usted escogió C#. Buena suerte con su proyecto!");
        break;
    case "c":
        Console.WriteLine("Usted escogió Java. Buena suerte con su proyecto!");
        break;
    case "d":
        Console.WriteLine("Usted escogió PHP. Buena suerte con su proyecto!");
        break;
    case "e":
        Console.WriteLine("Usted escogió Javascript. Buena suerte con su proyecto!");
        break;
    case "f":
        Console.WriteLine("Usted escogió Python. Buena suerte con su proyecto!");
        break;
    case "g":
        Console.WriteLine("Usted escogió Go. Buena suerte con su proyecto!");
        break;
    default:
        Console.WriteLine("Usted no escogió uno de los lenguajes listados anteriormente.");
        break;
}