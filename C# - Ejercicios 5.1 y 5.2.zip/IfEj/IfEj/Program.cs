﻿Console.WriteLine("Escriba su nombre: ");
string nombre = Console.ReadLine();

Console.WriteLine("Escriba su e-mail: ");
string email = Console.ReadLine();

Console.WriteLine("Escriba el porcentaje de su cupón sin el símbolo de porcentaje. En caso de no tener cúpón, ponga cero: ");
float porcentaje = float.Parse(Console.ReadLine()); // Que el porcentaje sea float es necesario para la oepración que determina el descuento más adelante

Console.WriteLine("Tenemos 4 productos en éste momento disponibles: ");
Console.WriteLine("(a) Empanada de arroz a $2000 COP");
Console.WriteLine("(b) Pastel de pollo a $3000 COP");
Console.WriteLine("(c) Buñuelo a $1000 COP");
Console.WriteLine("(d) Papa Rellena a $2500 COP");
Console.WriteLine("Ponga aquí la letra del producto que quiere comprar sin paréntesis: ");
string producto_elegido = Console.ReadLine();

int empanada = 2000;
int pastel_de_pollo = 3000;
int bunuelo = 1000;
int papa_rellena = 2500;
float descuento = 0f;
float precio_final = 0f;

if (porcentaje == 0) {
    switch (producto_elegido) {
        case "a":
            Console.WriteLine("Usted eligió una Empanada sin descuento, el precio es $2000.");
            break;
        case "b":
            Console.WriteLine("Usted eligió un Pastel de Pollo sin descuento, el precio es $3000.");
            break;
        case "c":
            Console.WriteLine("Usted eligió un Buñuelo sin descuento, el precio es $1000.");
            break;
        case "d":
            Console.WriteLine("Usted eligió una Papa Rellena sin descuento, el precio es $2500.");
            break;
        default:
            Console.WriteLine("Usted no eligió un producto de la lista.");
            break;
    }
}
else if (porcentaje == 100) {
    switch (producto_elegido)
    {
        case "a":
            Console.WriteLine("Usted eligió una Empanada con 100% de descuento, el precio es $0.");
            break;
        case "b":
            Console.WriteLine("Usted eligió un Pastel de Pollo con 100% de descuento, el precio es $0.");
            break;
        case "c":
            Console.WriteLine("Usted eligió un Buñuelo con 100% de descuento, el precio es $0.");
            break;
        case "d":
            Console.WriteLine("Usted eligió una Papa Rellena con 100% de descuento, el precio es $0.");
            break;
        default:
            Console.WriteLine("Usted no eligió un producto de la lista.");
            break;
    }
}
else if (porcentaje > 100)
{
    Console.WriteLine("Usted puso un porcentaje mayor a 100% y eso es inválido.");
}
else { // Haciendo la condición manualmente con otro else if tampoco arregla el problema
    switch (producto_elegido)
    {
        case "a":
            descuento = (porcentaje / 100) * 2000;
            precio_final = 2000 - descuento;
            Console.WriteLine("Usted eligió una Empanada con " + porcentaje + "% de descuento que es " + descuento + ", así que el precio es $" + precio_final + ".");
            break;
        case "b":
            descuento = (porcentaje / 100) * 3000;
            precio_final = 3000 - descuento;
            Console.WriteLine("Usted eligió una Empanada con " + porcentaje + "% de descuento que es " + descuento + ", así que el precio es $" + precio_final + ".");
            break;
        case "c":
            descuento = (porcentaje / 100) * 1000;
            precio_final = 1000 - descuento;
            Console.WriteLine("Usted eligió una Empanada con " + porcentaje + "% de descuento que es " + descuento + ", así que el precio es $" + precio_final + ".");
            break;
        case "d":
            descuento = (porcentaje / 100) * 2500;
            precio_final = 2500 - descuento;
            Console.WriteLine("Usted eligió una Empanada con " + porcentaje + "% de descuento que es " + descuento + ", así que el precio es $" + precio_final + ".");
            break;
        default:
            Console.WriteLine("Usted no eligió un producto de la lista.");
            break;
    }
}