﻿Cliente primerCliente = new Cliente("John", 464222, "Calle 96 #77-12", "johnpachito@gmail.com", true);
Console.WriteLine(primerCliente);

public struct Cliente {
    public Cliente(string nombre, int telefono, string direccion, string email, bool esNuevo) {
        Nombre = nombre;
        Telefono = telefono;
        Direccion = direccion;
        Email = email;
        EsNuevo = esNuevo;
    }

    public string Nombre { get; set; }

    public int Telefono { get; set; }

    public string Direccion { get; set; }

    public string Email { get; set; }

    public bool EsNuevo { get; set; }

    public override string ToString() => $"({Nombre}, {Telefono}, {Direccion}, {Email}, {EsNuevo})";
}