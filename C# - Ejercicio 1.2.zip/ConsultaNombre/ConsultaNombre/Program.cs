﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Introduce tu nombre aquí: ");
string nombre = Console.ReadLine();
Console.WriteLine("Tu nombre es " + nombre);
