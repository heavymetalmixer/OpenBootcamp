﻿int condicional = 0;
int contadorP = 0;
int contadorN = 0;

do {
    Console.WriteLine("Introduzca el número a contar: ");
    condicional = Convert.ToInt16(Console.ReadLine());

    if (condicional > 0) {
        contadorP += 1;
    } 
    else if (condicional < 0) {
        contadorN += 1;
    }
} while (condicional != 0);

Console.WriteLine("La cantidad de números positivos es " + contadorP);
Console.WriteLine("La cantidad de números negativos es " + contadorN);