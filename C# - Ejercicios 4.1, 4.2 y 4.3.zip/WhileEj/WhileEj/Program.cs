﻿Console.WriteLine("Por favor introduzca el número que quiere multiplicar aquí: ");
int numero1 = Convert.ToInt32(Console.ReadLine());

int i = 1;

while (i <= 10) {
    Console.WriteLine(numero1 * i);
    i += 1;
}