﻿int x;
int y;
int cuadrados;
bool relleno;

Console.WriteLine("Introduzca la dimensión X: ");
x = Convert.ToInt16(Console.ReadLine());
Console.WriteLine("Introduzca la dimensión Y: ");
y = Convert.ToInt16(Console.ReadLine());
Console.WriteLine("Introduzca la cantidad de cuadrados a dibujar con las anteriores dimensiones: ");
cuadrados = Convert.ToInt16(Console.ReadLine());
Console.WriteLine("Deberían estar rellenos?: "); //Just don't put anything other than true or false, or this is gonna explode really hard
relleno = Convert.ToBoolean(Console.ReadLine());


if (relleno) { // Si relleno es true entonces simplemente imprime * en todas las líneas de manera horizontal
    for (int i = 1; i <= y; i += 1) {
        for (int j = 1; j <= cuadrados; j += 1)
        {
            for (int k = 1; k <= x; k += 1) // Impresion horizontal de cada linea
            {
                Console.Write("*");
            }
            Console.Write(" "); // Espacio para separar las la primera linea de cada cuadro
        }
        Console.Write("\n"); // Avanza a la siguiente linea para poder imprimir todas las filas
    }
    
}
else { // Si relleno es false entonces los for para x y y se parten en 3 condiciones Primera y última lineas imprimen todo, y lo que haya en el medio solo
    // primera y última columna tienen *, mientras que el resto tienen un espacio
    for(int i = 1; i <= y; i += 1) {
        for (int j = 1; j <= cuadrados; j += 1)
        {
            if (i == 1) { // Decide qué fila debe ir con *
                for (int k = 1; k <= x; k += 1) // Impresion horizontal de cada linea
                {
                    Console.Write("*");
                }
                Console.Write(" "); // Espacio para separar la primera linea de cada cuadro
            }
            
            else if (i > 1 && i < y) {
                for (int k = 1; k <= x; k += 1) // Impresion horizontal de cada linea
                {
                    if (k == 1) // Decide qué columna debe ir con *
                    {
                        Console.Write("*");
                    }
                    else if (k > 1 && k < x)
                    {
                        Console.Write(" ");
                    }
                    else
                    {
                        Console.Write("*");
                    }

                }
                Console.Write(" "); // Espacio para separar las la primera linea de cada cuadro
            }
            else {
                for (int k = 1; k <= x; k += 1) // Impresion horizontal de cada linea
                {
                    Console.Write("*");
                }
                Console.Write(" "); // Espacio para separar la primera linea de cada cuadro
            }
        }
        Console.Write("\n"); // Avanza a la siguiente linea para poder imprimir todas las filas
    }
}
    
   
//}