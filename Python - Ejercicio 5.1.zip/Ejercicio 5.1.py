def anio_bisiesto(anio: int):
    # Si el año indicado es fin de siglo (como 2000), entonces se calcula si tiene división entera
    # por 400 para ser clasificado como bisiesto.
    if anio % 100 == 0:
        if anio % 400 == 0:
            print("El año", anio, "es bisiesto.")
        else:
            print("El año", anio, "NO es bisiesto.")
    
    # Aquí se hace el típico cálculo para saber si un año es bisiesto
    else:
        if anio % 4 == 0:
            print("El año", anio, "es bisiesto.")
        else:
            print("El año", anio, "NO es bisiesto.")

anio_bisiesto(2000)
anio_bisiesto(1900)
anio_bisiesto(2024)
anio_bisiesto(2025)