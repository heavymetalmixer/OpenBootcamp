maxi: int = 100
mini: int = 1

while maxi >= mini:
    print(maxi)
    maxi -= 1